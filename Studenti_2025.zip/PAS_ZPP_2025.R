setwd("C:/Users/helik/Dropbox/Vyuka/Predmety/PAS/PAS_IS/PAS_API_testy_AaL_ZS_24_25/Studenti_2025-01-08")
load("cars.RData")
attach(cars)

library(DescTools)

